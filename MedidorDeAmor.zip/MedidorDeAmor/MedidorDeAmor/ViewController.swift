//
//  ViewController.swift
//  MedidorDeAmor
//
//  Created by g277 DIT UPM on 12/11/14.
//  Copyright (c) 2014 g277 DIT UPM. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var n : NSDate!
    var m : NSDate!
    var c : NSDate!
    
    @IBOutlet weak var resultado: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
       
        
        
    }
    override func  viewDidAppear(animated: Bool) {
        pintaNaranja()
    }
    
    private func pintaNaranja(){
        print("Naranja")
        
       

       
        var n2 = -1
        var m2 = -1
        var c2 = -1
        
        println(n)
        println(m)
        println(c)
        
        if ((n != nil) & (c != nil) & (m != nil)){
            var t1 = n?.timeIntervalSinceNow
            
            n2 = Int(floor(t1!/60/60/24))
            
            var t2 = c?.timeIntervalSinceNow
            
            c2 = Int(floor(t2!/60/60/24))
            
            var t3 = m?.timeIntervalSinceNow
            
            m2 = Int(floor(t3!/60/60/24))
            
            
            
            
            var diasVividos = n2 - c2
            var diasTotales = n2 - m2
            var diasJuntos = c2 - m2
            
            
            if (n.compare(c) == NSComparisonResult.OrderedAscending) && (c.compare(m) == NSComparisonResult.OrderedAscending) && diasTotales != 0 {
                
                
                var porcentaje = Int((Double(diasVividos) / Double(diasTotales))*100.0)
                var naranja = 100 - porcentaje
                
                if 0 <= naranja && naranja <= 100 {
                    resultado.text = "Tu amor es tu " + "\(naranja) % naranja"
                    println("Tu amor es tu " + "\(naranja) % naranja")
                }
          
            }
            else{
                showAlert()
            }
        }
    }
    
    @IBAction func comenzar(segue:UIStoryboardSegue) {
    }
    
    func showAlert() {
        let alertController = UIAlertController(title: "Te equivocaste!", message: "Repita", preferredStyle: .Alert)
        
        let defaultAction = UIAlertAction(title: "OK", style: .Default, handler: nil)
        alertController.addAction(defaultAction)
        
        presentViewController(alertController, animated: true, completion: nil)
    }

}

