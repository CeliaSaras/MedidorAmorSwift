//
//  Patatas.swift
//  MedidorDeAmor
//
//  Created by g277 DIT UPM on 12/11/14.
//  Copyright (c) 2014 g277 DIT UPM. All rights reserved.
//

import UIKit



class Patatas: UIViewController {
    var n : NSDate?
    var m : NSDate?
    var c : NSDate?

    @IBOutlet weak var nacimiento: UIDatePicker!
    
    @IBOutlet weak var conocer: UIDatePicker!
    
    @IBOutlet weak var morir: UIDatePicker!
    
    
    @IBAction func selecM(sender: UIDatePicker) {
    }
   
    @IBAction func selecC(sender: UIDatePicker) {
    }
    
    @IBAction func selecN(sender: UIDatePicker) {
    }
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
       /* if segue.identifier == "Inicio" {
            print("Inicio")
            let ivc = segue.destinationViewController as ViewController
            
            ivc.n = nacimiento.date
           
            }*/
        if segue.identifier == "Conocer" {
            println("Conocer")
            let ivc = segue.destinationViewController as Patatas
            
            ivc.c = conocer.date
            ivc.n = n
        }
        if segue.identifier == "Morir" {
            println("Morir")
            let ivc = segue.destinationViewController as ViewController
            
            ivc.m = morir.date
            ivc.n = n
            ivc.c = c

        }
        
        if segue.identifier == "Nacer" {
            println("Nacer")
            let ivc = segue.destinationViewController as Patatas
            
            ivc.n = nacimiento.date
        }
        
        
    }




}
